import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [url, setUrl] = useState('');
  const [body, setBody] = useState('{}');
  const [response, setResponse] = useState('');

  const handleTest = async () => {
    try {
      const res = await axios.post(url, JSON.parse(body));
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (err) {
      setResponse(err.toString());
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>API Flow Tester</h2>
      <input value={url} onChange={e => setUrl(e.target.value)} placeholder="API URL" style={{ width: '100%' }} />
      <textarea value={body} onChange={e => setBody(e.target.value)} rows={10} style={{ width: '100%' }} />
      <button onClick={handleTest}>Test API</button>
      <pre>{response}</pre>
    </div>
  );
}

export default App;